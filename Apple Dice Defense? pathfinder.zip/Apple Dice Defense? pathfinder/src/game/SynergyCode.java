package game;

import acm.graphics.GOval;
import acm.graphics.GPolygon;

import java.awt.*;

public interface SynergyCode extends TileCode, DesignCode, BulletCode{
    default String secondaryName(){
        return null;
    }
    default String secondaryDescription(){
        return null;
    }
    Color getColor2(GTile tile);
    default void configureDice(GTile tile){
        if (tile.range != null) {
            GlobalVariables.screen.remove(tile.range);
        }
        tile.ticksLeft = tile.getAttackSpeed();
        Color v = getColor(tile);
        Color v2 = getColor2(tile);
                tile.o.add(new GOval((double)tile.size/4-(double)tile.size/14,(double)tile.size/2-(double)tile.size/14,(double)tile.size/7,(double)tile.size/7));
                tile.o.add(new GOval((double)tile.size*3/4-(double)tile.size/14,(double)tile.size/2-(double)tile.size/14,(double)tile.size/7,(double)tile.size/7));
                tile.o.add(new GOval((double)tile.size/4-(double)tile.size/14,(double)tile.size/4-(double)tile.size/14,(double)tile.size/7,(double)tile.size/7));
                tile.o.add(new GOval((double)tile.size*3/4-(double)tile.size/14,(double)tile.size*3/4-(double)tile.size/14,(double)tile.size/7,(double)tile.size/7));
                tile.o.add(new GOval((double)tile.size/4-(double)tile.size/14,(double)tile.size*3/4-(double)tile.size/14,(double)tile.size/7,(double)tile.size/7));
                tile.o.add(new GOval((double)tile.size*3/4-(double)tile.size/14,(double)tile.size/4-(double)tile.size/14,(double)tile.size/7,(double)tile.size/7));
        for (GOval z: tile.o) {
            z.setFillColor(z.getX() > tile.size/2 ? v:v2);
            z.setFilled(true);
            tile.add(z);
        }
        tile.remove(tile.g);
        for (int i = 0; i < 2; i++) {
            GPolygon p = new GPolygon();
            tile.stuff.add(p);
            p.setFillColor(new Color(0,125,0));
            p.setColor(i == 0 ? v : v2);
            p.setFilled(true);
            int size = tile.size;
            p.addVertex(size/2,0);
            p.addVertex(size/4 + (i*size/2),0);
            p.addVertex(size*i,size/2);
            p.addVertex(size/4 + (i*size/2),size);
            p.addVertex(size/2,size);
            tile.add(p);
            p.sendToBack();
        }
        int rangeAmt = tile.getRange();
        tile.range = new GOval((rangeAmt*100)+50,(rangeAmt*100)+50);
        tile.range.setFillColor(new Color(0, 250, 200, 75));
        tile.range.setFilled(true);
        GlobalVariables.screen.add(tile.range,tile.g.getWidth()/2-tile.range.getWidth()/2+GlobalVariables.getPositionOf(tile.x,tile.y).getX(),tile.g.getHeight()/2-tile.range.getHeight()/2+GlobalVariables.getPositionOf(tile.x,tile.y).getY());
        tile.range.setVisible(false);
    }
    int[] synergyNumbers();
}
