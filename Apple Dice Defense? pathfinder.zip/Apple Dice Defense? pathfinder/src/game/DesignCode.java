package game;

import acm.graphics.GOval;

import java.awt.*;

public interface DesignCode {
    Color getColor(GTile tile);
    default Color getColor(GProjectile bullet){
        return getColor(bullet.owner);
    }
    default void configureDice(GTile tile){
        if (tile.range != null) {
            GlobalVariables.screen.remove(tile.range);
        }
        tile.ticksLeft = tile.getAttackSpeed();
        Color v = getColor(tile);
        if (tile.diceAmount%2==1){
            tile.o.add(new GOval((double)tile.size/2-(double)tile.size/14,(double)tile.size/2-(double)tile.size/14,(double)tile.size/7,(double)tile.size/7));
        }
        switch(tile.diceAmount/2){
            case 3:
                tile.o.add(new GOval((double)tile.size/4-(double)tile.size/14,(double)tile.size/2-(double)tile.size/14,(double)tile.size/7,(double)tile.size/7));
                tile.o.add(new GOval((double)tile.size*3/4-(double)tile.size/14,(double)tile.size/2-(double)tile.size/14,(double)tile.size/7,(double)tile.size/7));
            case 2:
                tile.o.add(new GOval((double)tile.size/4-(double)tile.size/14,(double)tile.size/4-(double)tile.size/14,(double)tile.size/7,(double)tile.size/7));
                tile.o.add(new GOval((double)tile.size*3/4-(double)tile.size/14,(double)tile.size*3/4-(double)tile.size/14,(double)tile.size/7,(double)tile.size/7));
            case 1:
                tile.o.add(new GOval((double)tile.size/4-(double)tile.size/14,(double)tile.size*3/4-(double)tile.size/14,(double)tile.size/7,(double)tile.size/7));
                tile.o.add(new GOval((double)tile.size*3/4-(double)tile.size/14,(double)tile.size/4-(double)tile.size/14,(double)tile.size/7,(double)tile.size/7));
        }
        for (GOval z: tile.o) {
            z.setFillColor(v);
            z.setFilled(true);
            tile.add(z);
        }
        tile.g.setColor(v);
        int rangeAmt = tile.getRange();
        tile.range = new GOval((rangeAmt*100)+50,(rangeAmt*100)+50);
        tile.range.setFillColor(new Color(0, 250, 200, 75));
        tile.range.setFilled(true);
        GlobalVariables.screen.add(tile.range,tile.g.getWidth()/2-tile.range.getWidth()/2+GlobalVariables.getPositionOf(tile.x,tile.y).getX(),tile.g.getHeight()/2-tile.range.getHeight()/2+GlobalVariables.getPositionOf(tile.x,tile.y).getY());
        tile.range.setVisible(false);
    }
}
