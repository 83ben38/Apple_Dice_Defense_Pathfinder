package game;

import acm.graphics.GPoint;
import acm.graphics.GPolygon;
import acm.program.Program;
import svu.csc213.Dialog;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.*;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ConcurrentModificationException;
import java.util.Scanner;

import static acm.util.JTFTools.pause;

public class GlobalVariables {
    static ArrayList<String> names = new ArrayList<>();
    static ArrayList<EventListener> listeners = new ArrayList<>();
    static ArrayList<DesignCode> colors = new ArrayList<>();
    static{
        colors.add(new DesignCode() {
            @Override
            public Color getColor(GTile tile) {
                return null;
            }
            @Override
            public Color getColor(GProjectile bullet) {
                return Color.black;
            }
        });
        colors.add(tile -> Color.green);
        colors.add(tile -> Color.red);
        colors.add(tile -> Color.blue);
        colors.add(tile -> Color.yellow);
        colors.add(tile -> Color.cyan);
        colors.add(tile -> new Color(150, 75, 255));
        colors.add(tile -> new Color(50, 0, 125));
        colors.add(tile -> new Color(75, 30, 25));
        colors.add(tile -> Color.orange);
        colors.add(tile -> new Color(150, 255, 150));
        colors.add(tile -> new Color(125, 150, 75));
        colors.add(tile -> Color.black);
        colors.add(tile -> new Color(125,0,0));
        colors.add(tile -> Color.pink);
        colors.add(tile -> Color.magenta);
        colors.add(new DesignCode() {
            @Override
            public Color getColor(GTile tile) {
                return Color.white;
            }
            public void configureDice(GTile tile){
                DesignCode.super.configureDice(tile);
                while (tile.stuff.size() > 0){
                    tile.remove(tile.stuff.get(0));
                    tile.stuff.remove(0);
                }
                GPoint[] i = new GPoint[]{new GPoint(12.5,0),new GPoint(37.5,0),new GPoint(50,25),new GPoint(37.5,50),new GPoint(12.5,50),new GPoint(0,25),new GPoint(12.5,0)};
                Color[] c = new Color[]{Color.red,Color.orange,Color.yellow,Color.green,Color.blue,Color.magenta};
                for (int j = 0; j < i.length-1; j++) {
                    GPolygon p = new GPolygon();
                    p.addVertex(i[j].getX(),i[j].getY());
                    p.addVertex(i[j+1].getX(),i[j+1].getY());
                    p.addVertex(((i[j+1].getX()-25)*0.8)+25,((i[j+1].getY()-25)*0.8)+25);
                    p.addVertex(((i[j].getX()-25)*0.8)+25,((i[j].getY()-25)*0.8)+25);
                    if (tile.getThings()[j]){
                        p.setFilled(true);
                        p.setFillColor(c[j]);
                    }
                    p.setColor(c[j]);
                    tile.add(p);
                    tile.stuff.add(p);
                    p.sendToBack();
                }
                tile.g.sendToBack();
            }
        });
        colors.add(new DesignCode() {
            @Override
            public Color getColor(GTile tile) {
                switch (tile.phase) {
                    case 1 -> {
                        return new Color(250, 250, 125);
                    }
                    case 2 -> {
                        return new Color(175, 175, 100);
                    }
                    default -> {
                        return new Color(150, 150, 50);
                    }
                }
            }
            @Override
            public Color getColor(GProjectile bullet){
                if (bullet.out){
                    return new Color(150, 150, 50);
                }
                else{
                    return new Color(250, 250, 125);
                }
            }
        });
        colors.add(tile -> new Color(100,0,100));
        colors.add(tile -> new Color(0,178,255));
        colors.add(tile -> new Color(255,142,0));
        String[] namess = new String[]{"Green dice", "Fire dice", "Water dice", "Electric dice", "Ice dice", "Growth dice", "Orbit dice", "Multi-projectile dice", "Buff dice", "Trapper dice", "Zombie dice", "Bomb dice", "Flamethrower dice", "Anti-pierce dice", "Effect amplifier dice", "Rainbow dice", "Storm dice", "Randomizer dice", "Sniper dice", "Laser dice"};
        names.addAll(Arrays.asList(namess));
        listeners.add(new EventListener() {
            @Override
            public void placed(GTile placed) {
                for (GTile[] someTiles : GlobalVariables.tiles) {
                    for (GTile tile : someTiles) {
                        if (tile.dice && tile.diceType == 16) {
                            tile.configureDice();
                        }
                    }
                }
            }

            @Override
            public void pickedUp(GTile pickedUp) {
                for (GTile[] someTiles : GlobalVariables.tiles) {
                    for (GTile tile : someTiles) {
                        if (tile.dice && tile.diceType == 16) {
                            tile.configureDice();
                        }
                    }
                }
            }

            @Override
            public void diceGrown(GTile grown) {
                for (GTile[] someTiles : GlobalVariables.tiles) {
                    for (GTile tile : someTiles) {
                        if (tile.dice && tile.diceType == 16) {
                            tile.configureDice();
                        }
                    }
                }
            }
        });
    }
    static volatile String location = URLDecoder.decode(ADD.class.getProtectionDomain().getCodeSource().getLocation().getPath(), StandardCharsets.UTF_8);
    static int[] v = new int[11];
    static boolean wave = false;
    static boolean FF = false;
    static volatile boolean enemiesLeft = false;
    static int ticksTaken = 0;
    static int waveN = 0;
    static int lives = 100;
    static GTile pickedUp;
    public static ArrayList<GApple> enemies = new ArrayList<>();
    static ArrayList<GApple> zombies = new ArrayList<>();
    static int[][] waveData = {{1,1,2,3},{2,2,0,2},{2,1,1,5},{5,2,0,1},{1,1,1,10},{3,4,0,1},{5,2,2,4},{3,2,1,10},{20,2,0,1},{6,6,2,6},{20,1,1,5},{5,3,1,30},{100,3,0,1},{20,10,3,3},{20,3,1,50},{100,3,3,5},{250,4,0,1},{50,20,3,5},{250,4,3,5},{100,3,1,50},{500,5,0,1},{100,25,1,10},{10,4,0,300},{500,3,2,20},{2500,4,0,1}};
    public static GTile[][] tiles = new GTile[20][10];
    static ArrayList<GProjectile> projectiles = new ArrayList<>();
    static ADD screen;
    static volatile boolean diceGotten = false;
    static volatile boolean already = false;
    static volatile boolean starting = false;
    static ArrayList<GTile> path = new ArrayList<>();
    public static void tick() {
        for (int i = 0; i < enemies.size(); i++) {
            enemies.get(i).tick();
        }
        for (int i = 0; i < zombies.size(); i++) {
            zombies.get(i).tick();
        }
        for (GTile[] someTiles : tiles) {
            for (GTile tile : someTiles) {
                if (tile.dice) {
                    tile.tick();
                }
            }
        }
        for (int i = 0; i < projectiles.size(); i++) {
            projectiles.get(i).tick();
        }
        try {
            enemies.sort((o1, o2) -> {
                if (o1.pathAmount > o2.pathAmount) {
                    return -1;
                } else if (o2.pathAmount > o1.pathAmount) {
                    return 1;
                } else {
                    if (o1.pathLeft < o2.pathLeft) {
                        return -1;
                    } else if (o2.pathLeft < o1.pathLeft) {
                        return 1;
                    }
                    return 0;
                }
            });
        } catch (ConcurrentModificationException ignored) {

        }
        if (lives <= 0) {
            Dialog.showMessage("You lose!");
            screen.exit();
        }
        ticksTaken++;
    }
    public static boolean isNextTo(int x1, int y1, int x2, int y2){
        if (x2%2==1){
            if (y2 == y1-1){
                return Math.abs(x1 - x2) < 2;
            }
            else if (y2 == y1){
               return Math.abs(x1 - x2) == 1;
            }
            else if (y2-1 == y1){
                return x1 == x2;
            }
            else{
                return false;
            }
        }
        else{
            if (y2-1 == y1){
                return Math.abs(x1 - x2) < 2;
            }
            else if (y2 == y1){
                return Math.abs(x1 - x2) == 1;
            }
            else if (y2 == y1-1){
                return x1 == x2;
            }
            else{
                return false;
            }
        }
    }
    public static GPoint getPositionOf(int x, int y){
        GPoint p = new GPoint();
        p.setLocation(x*38,(y+((double)x%2/2))*50);
        return p;
    }
    public static GTile getGTileAt(int x, int y){
        if (x/38%2==0){
            return tiles[x/38][(y/50)];
        }
        else{
            return tiles[x/38][((y-25)/50)];
        }
    }
    public static int randomInt(int from, int to){
        return (int)(Math.random()*(to-from+1)) + from;
    }
    public static boolean pathFind(){
        ArrayList<GTile> possible = null;
        for (GTile t : tiles[0]) {
            for (GTile[] someTiles : tiles) {
                for (GTile s : someTiles) {
                    s.z = 300;
                }
            }
            ArrayList<GTile> s = t.pathFind(new ArrayList<>());
            if (possible != null){
                if (s != null) {
                    if (s.size() < possible.size()) {
                        possible = s;
                    }
                }
            }
            else{
                possible = s;
             }
        }
        if(possible == null){
            return false;
        }
            path = possible;
        return true;
    }
    public static void startWave(){
        if (already){
            return;
        }
        already = true;
        for (EventListener listener: listeners) {
            listener.roundStarted(waveN);
        }
        pathFind();
        wave = true;
        enemiesLeft = true;
        ticksTaken = 0;
        // make enemies properly spaced and stuff
        if (waveN < waveData.length) {
            for (int i = 0; i < waveData[waveN][3]; i++) {
                GApple p = new GApple(waveData[waveN][0], waveData[waveN][1]);
                screen.addToScreen(p);
                enemiesLeft = true;
                for (int j = 0; j < 10 * GlobalVariables.waveData[waveN][2]; j++) {
                    tick();
                    if (FF) {
                        //fast forward is 100 fps
                        pause(10);
                    } else {
                        //slower is 40 fps
                        pause(25);
                    }
                }
            }
        }
        else{
            for (int i = 0; i < ((waveN-22)*10); i++) {
                GApple p = new GApple(waveN*waveN*waveN*waveN/500,waveN-22);
                screen.addToScreen(p);
                enemiesLeft = true;
                for (int j = 0; j < 25 * Math.pow(0.75,(waveN-22)); j++) {
                    tick();
                    if (FF) {
                        //freeplay fast forward is 250 fps
                        pause(4);
                    } else {
                        pause(10);
                    }
                }
            }
        }

        wave = false;
        // continue ticking while there are enemies left
        while(enemiesLeft){
            tick();
            if (waveN < waveData.length){
                if (FF) {
                    pause(10);
                } else {
                    pause(25);
                }
            }
            else {
                if (FF) {
                    pause(4);
                } else {
                    pause(10);
                }
            }
        }
        //remove all the projectiles, zombies
        while(projectiles.size() > 0){
            projectiles.get(0).remove();
        }
        while(zombies.size() > 0){
            zombies.get(0).remove();
        }
        //if the wave was a freeplay wave, have a chance to get a freeplay dice
        waveN++;
        //get a dice at the end of the wave
        screen.getADice();
        already = false;
    }
    public static void run2(){
        File f = new File(location + "/saveFile.txt");
        String s = null;
        try {
            s = new Scanner(f).next();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        for (int i = 1; i < s.length()+1; i++) {
            if (s.charAt(i-1) == '1') {
                GTile t = new GTile(50, ((i - 1) % 5) + 2, 4 + ((i - 1) / 5), i);
                screen.addToScreen(t);
            }
        }
        GTile[] z = new GTile[5];
        for (int i = 1; i < 6; i++) {
            GTile t = new GTile(50,i+1,2);
            screen.addToScreen(t);
            z[i-1] = t;
        }
        JButton j = new JButton("GO!");
        screen.add(j, Program.SOUTH);

        j.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                boolean exit = true;
                for (int i = 0; i < 5; i++) {
                    if (!z[i].dice){
                        exit = false;
                    }
                }
                if (exit) {
                    starting = true;
                    j.setVisible(false);
                    for (int i = 0; i < 4; i++) {
                        v[i] = z[0].diceType;
                    }
                    for (int i = 1; i < 4; i++) {
                        for (int k = (i*2) + 2; k < (i*2) + 4; k++) {
                            v[k] = z[i].diceType;
                        }
                    }
                    v[10] = z[4].diceType;
                    screen.removeAll();
                    screen.waveStarter = j;
                    j.removeMouseListener(this);
                    screen.run1();
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });
    }
    public static void exsist(){
        run2();
    }
    public static void getDice(int i) throws IOException {
        File f = new File(location + "saveFile.txt");
        String s = null;
        try {
            s = new Scanner(f).next();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        s = s.substring(0,i) + "1" + s.substring(i+1);
        FileWriter w = new FileWriter(location + "saveFile.txt");
        w.append(s);
        w.flush();
    }
    public static void win(){
        String s = "";
        try {
            s = new Scanner(new File(location + "saveFile.txt")).next();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        if (s.contains("0")){
            int o = s.indexOf("0");
            String v = s.substring(0,o) + "1" + s.substring(o+1);
            if (v.contains("0")){
                int r = randomInt(0,s.length()-1);
                while (s.charAt(r) == '1'){
                    r = randomInt(0,s.length()-1);
                }
                int k = randomInt(0,s.length()-1);
                while (s.charAt(k) == '1' || k == r){
                    k = randomInt(0,s.length()-1);
                }
                String[] names = GlobalVariables.names.toArray(new String[0]);
                try {
                    if (Dialog.getYesOrNo("Would you like " + names[r] + "(Yes), or " + names[k] + "(No)?")) {
                        getDice(r);
                    } else {
                        getDice(k);
                    }
                }
                catch(IOException ignored){

                }
            }
            else{
                Dialog.showMessage("You have unlocked all the dice.");
                try {
                    getDice(o);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    public static void addButton(){
        JButton b = new JButton("Done");
        screen.fastForward = b;
        screen.add(b,Program.SOUTH);
        b.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                starting = false;
                screen.readyToGo();
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });
        screen.waveStarter.setText("Random map");
        screen.waveStarter.removeMouseListener(screen.waveStarter.getMouseListeners()[0]);
        screen.waveStarter.setVisible(true);
        screen.waveStarter.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                for (GTile[] someTiles: tiles){
                    for (GTile t : someTiles) {
                        if (randomInt(1,3) == 1){
                            t.setPath();
                        }
                    }
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });
    }
    public static void pickedUp(GTile pickedUp){
        if (tiles[0][0] != null) {
            for (EventListener listener : listeners) {
                listener.pickedUp(pickedUp);
            }
        }
    }
    public static void placed(GTile placed){
        if (tiles[0][0] != null) {
            for (EventListener listener : listeners) {
                listener.placed(placed);
            }
        }
    }
    public static void merged(GTile merged1, GTile merged2, GTile result){
        for (EventListener list: listeners) {
            list.merged(merged1,merged2,result);
        }
    }
    public static void diceGrown(GTile grown){
        for (EventListener list: listeners) {
            list.diceGrown(grown);
        }
    }
}
