package game;

import java.awt.*;
import java.util.ArrayList;

public interface LevelCode {
    double[][] getWaveData();
    ArrayList<Integer> bannedTowers();
    double[] generateFreeplayWave(int wave);
    boolean rewardDice();
    default boolean rewardExtras(){
        return false;
    }
    String name();
    Color difficultyColor();
    default boolean rewardUpgrades(){
        return true;
    }
}
