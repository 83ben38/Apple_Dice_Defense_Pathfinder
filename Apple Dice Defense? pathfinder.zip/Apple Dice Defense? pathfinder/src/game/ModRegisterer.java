package game;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class ModRegisterer {
    public ModRegisterer(Class<? extends Mod> mod){
        Constructor constructor = null;
        try {
            constructor = mod.getConstructor();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }
        try {
            ((Mod) constructor.newInstance()).run();
        } catch (InstantiationException | InvocationTargetException | IllegalAccessException e) {
            e.printStackTrace();
        }
    }
}
