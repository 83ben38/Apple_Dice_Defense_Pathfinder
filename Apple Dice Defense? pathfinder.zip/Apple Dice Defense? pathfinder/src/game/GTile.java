package game;

import acm.graphics.*;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

public class GTile extends GCompound {
    static ArrayList<TileCode> code = new ArrayList<>();
    static{
        //0
        code.add(new TileCode() {});
        code.add(new TileCode() {
            @Override
            public int getRange(GTile tile) {
                return 0;
            }

            @Override
            public int getAttackSpeed(GTile tile) {
                return 192;
            }

            @Override
            public void fire(GTile tile) {
                for (int i = 0; i < 6; i++) {
                    tile.ticksLeft = tile.getAttackSpeed();
                    tile.projectiles.add(new GProjectile(tile.diceAmount, i, tile));
                }
            }
        });
        code.add(new TileCode() {
            @Override
            public int getRange(GTile tile) {
                return TileCode.super.getRange(tile)+1;
            }
        });
        code.add(new TileCode() {
            @Override
            public int getRange(GTile tile) {
                return TileCode.super.getRange(tile)+1;
            }

            @Override
            public int getAttackSpeed(GTile tile) {
                return 192;
            }
        });
        code.add(new TileCode() {
            @Override
            public int getRange(GTile tile) {
                return TileCode.super.getRange(tile)+2;
            }

            @Override
            public int getAttackSpeed(GTile tile) {
                return 192;
            }
        });
        //5
        code.add(new TileCode() {});
        code.add(new TileCode() {
            @Override
            public int getRange(GTile tile) {
                return 0;
            }

            @Override
            public int getAttackSpeed(GTile tile) {
                return 4;
            }

            @Override
            public void tick(GTile tile) {

            }

            @Override
            public void turnPassed(GTile tile) {
                tile.ticksLeft--;
                if (tile.ticksLeft == 0){
                    tile.setEmpty();
                    tile.setDice(GlobalVariables.v[GlobalVariables.randomInt(0,10)],tile.diceAmount+1);
                    GlobalVariables.diceGrown(tile);
                }
            }
        });
        code.add(new TileCode() {
            @Override
            public void tick(GTile tile) {
                if (tile.projectiles.size() < 1){
                    tile.projectiles.add(new GProjectile(tile.diceAmount,tile,false));
                }
                if (tile.projectiles.size() < 2 && tile.diceAmount > 4){
                    tile.projectiles.add(new GProjectile(tile.diceAmount,tile,true));
                }
                for (GProjectile p: tile.projectiles) {
                    p.tick();
                }
            }
        });
        code.add(new TileCode() {
            @Override
            public int getRange(GTile tile) {
                return TileCode.super.getRange(tile)+2;
            }

            @Override
            public int getAttackSpeed(GTile tile) {
                return 192;
            }

            @Override
            public void fire(GTile tile) {
                int number = tile.diceAmount;
                for (int i = 0; i < GlobalVariables.enemies.size(); i++) {
                    if (tile.calculateDistance(GlobalVariables.enemies.get(i).getX(), GlobalVariables.enemies.get(i).getY()) < (tile.getRange()+0.5) * 50) {
                        number--;
                        tile.projectiles.add(new GProjectile(tile.diceType, tile.diceAmount, GlobalVariables.enemies.get(i), tile));
                        if (number < 1){
                            break;
                        }
                    }
                }
                if (number < tile.diceAmount) {
                    tile.ticksLeft = tile.getAttackSpeed();
                }
            }
        });
        code.add(new TileCode() {
            @Override
            public int getAttackSpeed(GTile tile) {
                return 6;
            }

            @Override
            public void fire(GTile tile) {
                tile.nextTo = tile.getNextTo();
                for (GTile t: tile.getNextTo()) {
                    if (t.dice && t.diceType != 9){
                        t.tick();
                    }
                }
                tile.ticksLeft = tile.getAttackSpeed();
            }
        });
        //10
        code.add(new TileCode() {
            @Override
            public int getRange(GTile tile) {
                return TileCode.super.getRange(tile)+1;
            }

            @Override
            public void fire(GTile tile) {
                tile.nextTo =  tile.getPathInRange();
                if ( tile.nextTo.size() > 0) {
                    tile.projectiles.add(new GProjectile(tile.diceAmount,  tile.nextTo.get(GlobalVariables.randomInt(0,  tile.nextTo.size() - 1)), tile));
                    tile.ticksLeft =  tile.getAttackSpeed();
                }
            }
        });
        code.add(new TileCode() {
            @Override
            public int getRange(GTile tile) {
                return TileCode.super.getRange(tile)+2;
            }

            @Override
            public void tick(GTile tile) {
            }
        });
        code.add(new TileCode() {
            @Override
            public int getRange(GTile tile) {
                return TileCode.super.getRange(tile)+1;
            }

            @Override
            public void fire(GTile tile) {
                int number = -1;
                for (int i = 0; i < GlobalVariables.enemies.size(); i++) {
                    if (tile.calculateDistance(GlobalVariables.enemies.get(i).getX(), GlobalVariables.enemies.get(i).getY()) < (tile.getRange()+0.5) * 50 && !GlobalVariables.enemies.get(i).bombed) {
                        number = i;
                        break;
                    }
                }
                if (number > -1) {
                    tile.ticksLeft = tile.getAttackSpeed();
                    tile.projectiles.add(new GProjectile(tile.diceType, tile.diceAmount, GlobalVariables.enemies.get(number), tile));
                }
            }
        });
        code.add(new TileCode() {
            @Override
            public int getAttackSpeed(GTile tile) {
                return 24;
            }
        });
        code.add(new TileCode() {
            @Override
            public int getRange(GTile tile) {
                return TileCode.super.getRange(tile)+2;
            }

            @Override
            public int getAttackSpeed(GTile tile) {
                return 192;
            }
        });
        //15
        code.add(new TileCode() {
            @Override
            public int getRange(GTile tile) {
                return TileCode.super.getRange(tile)+1;
            }
        });
        code.add(new TileCode() {
            @Override
            public int getRange(GTile tile) {
                if (tile.getThings()[2]) {
                    return TileCode.super.getRange(tile)+2;
                }
                else{
                    return TileCode.super.getRange(tile)+1;
                }
            }

            @Override
            public int getAttackSpeed(GTile tile) {
                if (tile.getThings()[0]&&tile.getThings()[3]){
                    return 48;
                }
                else if (tile.getThings()[0]||tile.getThings()[3]){
                    return 96;
                }
                return 192;
            }
        });
        code.add(new TileCode() {
            @Override
            public int getAttackSpeed(GTile tile) {
                if (tile.phase > 1){
                    return 12;
                }
                else{
                    return 96;
                }
            }
            @Override
            public int getRange(GTile tile){
                return TileCode.super.getRange(tile)+1;
            }
            @Override
            public void tick(GTile tile) {
                if (GlobalVariables.ticksTaken%350 < 200){
                    if (tile.phase != 1){
                        tile.phase = 1;
                        tile.configureDice();
                        tile.ticksLeft = tile.getAttackSpeed();
                    }
                }
                else if (GlobalVariables.ticksTaken%350 < 300){
                    if (tile.phase != 2){
                        tile.phase = 2;
                        tile.configureDice();
                        tile.ticksLeft = tile.getAttackSpeed();
                    }
                }
                else {
                    if (tile.phase != 3){
                        tile.phase = 3;
                        tile.configureDice();
                        tile.ticksLeft = tile.getAttackSpeed();
                    }
                }
                TileCode.super.tick(tile);
            }

            @Override
            public void fire(GTile tile) {
                if (tile.phase == 3){
                    int number = -1;
                    for (int i = 0; i < GlobalVariables.enemies.size(); i++) {
                        if (tile.calculateDistance(GlobalVariables.enemies.get(i).getX(), GlobalVariables.enemies.get(i).getY()) < (tile.getRange()+0.5) * 50) {
                            number = i;
                            break;
                        }
                    }
                    if (number > -1) {
                        tile.ticksLeft = tile.getAttackSpeed();
                        tile.projectiles.add(new GProjectile(tile.diceAmount, tile,GlobalVariables.enemies.get(number)));
                    }
                }
                else {
                    TileCode.super.fire(tile);
                }
            }
        });
        code.add(new TileCode() {
            @Override
            public int getRange(GTile tile) {
                return 0;
            }

            @Override
            public void tick(GTile tile) {

            }
        });
        code.add(new TileCode() {
            @Override
            public int getRange(GTile tile) {
                return TileCode.super.getRange(tile)+4;
            }

            @Override
            public int getAttackSpeed(GTile tile) {
                return 192*4;
            }
        });
        //20
        code.add(new TileCode() {
            @Override
            public int getRange(GTile tile) {
                return tile.diceAmount+2;
            }

            @Override
            public void tick(GTile tile) {
                for (GTile t: tile.getNextToConnect()) {
                    boolean added = false;
                    for (GProjectile c: tile.projectiles) {
                        if ((((GConnectile)c).connector1 == t || ((GConnectile)c).connector2 == t)){
                            added = true;
                        }
                    }
                    if (!added){
                        tile.projectiles.add(new GConnectile(tile.diceAmount,tile,t));
                        t.projectiles.add(tile.projectiles.get(tile.projectiles.size()-1));
                    }
                }
                for (GProjectile p: tile.projectiles) {
                    p.tick();
                }
            }
        });
    }
    ArrayList<GProjectile> projectiles = new ArrayList<>();
    ArrayList<GTile> nextTo;
    public ArrayList<GObject> extras = new ArrayList<>();
    GOval range;
    GPolygon g = new GPolygon();
    ArrayList<GOval> o =  new ArrayList<>();
    ArrayList<GPolygon> stuff = new ArrayList<>();
    public boolean path = false;
    public boolean dice = false;
    public int diceType;
    public int diceAmount;
    int size;
    public int x;
    public int y;
    int ticksLeft;
    int phase = 1;
    int z;
    public GTile(int size, int x, int y){
        this.size = size;
        this.x = x;
        this.y = y;
        g.addVertex((double)size*1/4,0);
        g.addVertex((double)size*3/4,0);
        g.addVertex(size,(double)size/2);
        g.addVertex((double)size*3/4,size);
        g.addVertex((double)size*1/4,size);
        g.addVertex(0,(double)size/2);
        add(g);
        g.setFillColor(new Color(0,125,0));
        g.setFilled(true);
        MouseListener m = new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                try {
                    GTile.this.mouseClicked();
                } catch (CloneNotSupportedException ex) {
                    ex.printStackTrace();
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {
                if (range != null) {
                    range.setVisible(true);
                    sendToFront();
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                if (range != null) {
                    range.setVisible(false);
                    sendToBack();
                }
            }
        };
        this.addMouseListener(m);
    }
    public GTile(int lvl){
        diceType = GlobalVariables.v[GlobalVariables.randomInt(0,10)];
        diceAmount = lvl;
    }
    public GTile(int size, int x, int y, int diceType){
        this(size,x,y);
        setDice(diceType,1);
    }
    public void setPath(){
        path = true;
        if (GlobalVariables.pathFind()){
            g.setFillColor(Color.MAGENTA);
            range = null;
        }
        else{
            path = false;
        }
    }
    public void setEmpty(){
        if (range != null) {
            GlobalVariables.screen.remove(range);
        }
        range = null;
        dice = false;
        path = false;
        diceType = 0;
        while (stuff.size() > 0){
            remove(stuff.get(0));
            stuff.remove(0);
        }
        while(o.size() > 0){
            remove(o.get(0));
            o.remove(0);
        }
        while (extras.size() > 0){
            remove(extras.get(0));
            extras.remove(0);
        }
        g.setFillColor(new Color(0,125,0));
        g.setColor(Color.black);
        while (projectiles.size() > 0){
            projectiles.get(0).remove();
        }
    }
    public int getAttackSpeed(){
        return code.get(diceType).getAttackSpeed(this);
    }
    public void setDice(int type, int amount){
        dice = true;
        diceType = type;
        diceAmount = amount;
        configureDice();
    }
    public void configureDice(){
        GlobalVariables.colors.get(diceType).configureDice(this);
    }
    public boolean[] getThings(){
        boolean[] f = new boolean[]{false,false,false,false,false,false};
        if (GlobalVariables.tiles[0][0] != null) {
            if (x % 2 == 0) {
                if (y  > 0){
                    f[0] = GlobalVariables.tiles[x][y - 1].diceType == 16;
                    if (x < GlobalVariables.tiles.length-1){
                        f[1] = GlobalVariables.tiles[x+1][y - 1].diceType == 16;
                    }
                    if (x > 0){
                        f[5] = GlobalVariables.tiles[x-1][y - 1].diceType == 16;
                    }
                }
                if (y < GlobalVariables.tiles[0].length-1){
                    f[3] = GlobalVariables.tiles[x][y + 1].diceType == 16;
                }
                if (x > 0){
                    f[4] = GlobalVariables.tiles[x - 1][y].diceType == 16;
                }
                if (x < GlobalVariables.tiles.length-1){
                    f[2] = GlobalVariables.tiles[x + 1][y].diceType == 16;
                }
            } else {
                if (y  < GlobalVariables.tiles[0].length-1){
                    f[3] = GlobalVariables.tiles[x][y + 1].diceType == 16;
                    if (x < GlobalVariables.tiles.length-1){
                        f[2] = GlobalVariables.tiles[x+1][y + 1].diceType == 16;
                    }
                    f[4] = GlobalVariables.tiles[x-1][y + 1].diceType == 16;
                }
                if (y > 0){
                    f[0] = GlobalVariables.tiles[x][y-1].diceType == 16;
                }
                if (x > 0){
                    f[5] = GlobalVariables.tiles[x - 1][y].diceType == 16;
                }
                if (x < GlobalVariables.tiles.length-1){
                    f[1] = GlobalVariables.tiles[x + 1][y].diceType == 16;
                }
            }
        }
        return f;
    }
    private void mouseClicked() throws CloneNotSupportedException {
        if(GlobalVariables.starting){
            if (path){
                setEmpty();
            }
            else {
                setPath();
            }
        }
        else if (!(GlobalVariables.wave || GlobalVariables.enemiesLeft)){
            if (GlobalVariables.pickedUp == null && dice){
                GlobalVariables.pickedUp(this);
                GlobalVariables.pickedUp = (GTile)this.clone();
                setEmpty();
            }
            else if (GlobalVariables.pickedUp == null){
                /*nothing*/
            }
            else if (!dice && !path){
                setDice(GlobalVariables.pickedUp.diceType, GlobalVariables.pickedUp.diceAmount);
                if (GlobalVariables.tiles[0][0] != null) {
                    if (GlobalVariables.pathFind()) {
                        GlobalVariables.placed(this);
                        GlobalVariables.pickedUp = null;
                        if (diceType == 9) {
                            nextTo = getNextTo();
                        }
                    } else {
                        setEmpty();
                    }
                }
                else{
                    GlobalVariables.pickedUp = null;
                    if (diceType == 9) {
                        nextTo = getNextTo();
                    }
                }
            }
            else if (dice && GlobalVariables.pickedUp.diceType == diceType && GlobalVariables.pickedUp.diceAmount == diceAmount && diceAmount < 6){
                GTile starter = (GTile) this.clone();
                GlobalVariables.pickedUp = null;
                diceAmount++;
                int type = diceType;
                setEmpty();
                setDice(type,diceAmount);
                GlobalVariables.merged(starter,GlobalVariables.pickedUp,this);
            }
            else if (dice && GlobalVariables.pickedUp.diceType == 18 && GlobalVariables.pickedUp.diceAmount == diceAmount){
                GTile starter = (GTile) this.clone();
                GlobalVariables.pickedUp = null;
                diceAmount++;
                int type = GlobalVariables.v[GlobalVariables.randomInt(0,10)];
                setEmpty();
                setDice(type,diceAmount);
                GlobalVariables.merged(starter,GlobalVariables.pickedUp,this);
            }
        }
    }
    public void tick(){
        code.get(diceType).tick(this);
    }
    public double calculateDistance(double x, double y){
        return Math.sqrt(Math.pow(x-getX(),2)+Math.pow(y-getY(),2));
    }
    public int getRange(){
        return code.get(diceType).getRange(this);
    }
    public void fire(){
        code.get(diceType).fire(this);
    }
    public void turnPassed(){
        code.get(diceType).turnPassed(this);
    }
    @Override
    public double getWidth(){
        return g.getWidth();
    }
    public double getHeight(){
        return g.getHeight();
    }
    private ArrayList<GTile> getNextTo(){
        ArrayList<GTile> x = new ArrayList<>();
        for (GTile[] t : GlobalVariables.tiles) {
            for (GTile c : t) {
                if (c != null) {
                    if (calculateDistance(c.getX(), c.getY()) < (getRange()*50)+25 && c.dice) {
                        x.add(c);
                    }
                }
            }
        }
        return x;
    }
    private ArrayList<GTile> getNextToConnect(){
        ArrayList<GTile> x = new ArrayList<>();
        for (GTile[] t : GlobalVariables.tiles) {
            for (GTile c : t) {
                if (c != null) {
                    if (calculateDistance(c.getX(), c.getY()) < (getRange()*50)+25 && c.dice && c.diceType == 20 && c.diceAmount == diceAmount && c != this) {
                        x.add(c);
                    }
                }
            }
        }
        return x;
    }
    public ArrayList<GTile> getAround(){
        ArrayList<GTile> x = new ArrayList<>();
        for (GTile[] t : GlobalVariables.tiles) {
            for (GTile c : t) {
                if (c != null) {
                    if (GlobalVariables.isNextTo(this.x,y,c.x,c.y)) {
                        x.add(c);
                    }
                }
            }
        }
        return x;
    }
    private ArrayList<GTile> getPathInRange(){
        ArrayList<GTile> x = new ArrayList<>();
        for (GTile[] t : GlobalVariables.tiles) {
            for (GTile c : t) {
                if (c != null) {
                    if (calculateDistance(c.getX(), c.getY()) < (getRange()*50)+25 && GlobalVariables.path.contains(c)) {
                        x.add(c);
                    }
                }
            }
        }
        return x;
    }
    public int zombieStuff(GApple p){
        if (calculateDistance(p.getX(), p.getY()) < (getRange()*50)+25) {
            return diceAmount*diceAmount*3;
        }
        return 0;
    }
    public ArrayList<GTile> pathFind(ArrayList<GTile> i){
        i.add(this);
        if (path || dice){
            return null;
        }
        if (x == 19){
           return i;
        }
        else if (i.size() < z) {
            z = i.size();
            ArrayList<GTile> pathFind = null;
            for (GTile t : getAround()) {
                ArrayList<GTile> r = t.pathFind((ArrayList<GTile>) i.clone());
                if (pathFind != null) {
                    if (r != null) {
                        if (r.size() < pathFind.size()) {
                            pathFind = r;
                        }
                    }
                }
                else{
                    pathFind = r;
                }
            }
            return pathFind;
        }
        return null;
    }
}
