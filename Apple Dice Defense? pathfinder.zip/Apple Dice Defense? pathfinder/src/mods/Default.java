package mods;

public class Default extends game.Mod{
    @Override
    protected void run() {

    }
}
